package skies.remastered.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
public class FogRendererMixin {
	@Inject(
			method = "applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;",
			at = @At("RETURN")
	)
	private void skiesRemastered$matchingBlackFog(
			class_4184 camera,
			int viewDistance,
			class_9779 tickCounter,
			float f,
			class_638 world,
			CallbackInfoReturnable<Vector4f> cir
	) {
		class_5636 submersion = camera.method_19334();
		if (submersion == class_5636.field_27886
				|| submersion == class_5636.field_27885
				|| submersion == class_5636.field_27887) {
			return;
		}
		Vector4f color = cir.getReturnValue();
		color.set(0.0F, 0.0F, 0.0F, color.w());
		cir.setReturnValue(color);
	}
}
