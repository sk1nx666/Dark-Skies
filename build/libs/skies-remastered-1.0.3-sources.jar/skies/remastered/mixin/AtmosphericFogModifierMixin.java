package skies.remastered.mixin;

import net.minecraft.class_11398;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Terrain and distant chunks blend toward the atmospheric fog color from this modifier (sky-tinted),
 * not only the final {@link net.minecraft.class_758#method_3211} vector.
 */
@Mixin(class_11398.class)
public class AtmosphericFogModifierMixin {
	private static final int BLACK_ARGB = 0xFF000000;

	@Inject(
			method = "getFogColor(Lnet/minecraft/client/world/ClientWorld;Lnet/minecraft/client/render/Camera;IF)I",
			at = @At("RETURN"),
			cancellable = true
	)
	private void skiesRemastered$blackAtmosphericTint(
			class_638 world,
			class_4184 camera,
			int viewDistance,
			float skyDarkness,
			CallbackInfoReturnable<Integer> cir
	) {
		class_5636 submersion = camera.method_19334();
		if (submersion == class_5636.field_27886
				|| submersion == class_5636.field_27885
				|| submersion == class_5636.field_27887) {
			return;
		}
		cir.setReturnValue(BLACK_ARGB);
	}
}
