package skies.remastered.mixin;

import net.minecraft.class_12076;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9975.class)
public class SkyRenderingMixin {
	private static final int BLACK_SKY = 0xFF000000;

	@Inject(
			method = "updateRenderState(Lnet/minecraft/client/world/ClientWorld;FLnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/state/SkyRenderState;)V",
			at = @At("TAIL")
	)
	private void skiesRemastered$uniformDarkSky(
			class_638 world,
			float tickProgress,
			class_4184 camera,
			class_12076 state,
			CallbackInfo ci
	) {
		state.field_63097 = BLACK_SKY;
		state.field_63095 = 0;
	}
}
